/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Mauricio
 */
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

public class PessoaJuridicaRepo {
    private ArrayList<PessoaJuridica> listaPessoaJuridica;

    //CONSTRUTOR
    public PessoaJuridicaRepo() {
        listaPessoaJuridica = new ArrayList<>();
    }

    //MÉTODO INSERIR
    public void Inserir(PessoaJuridica pessoaJuridica) {
        listaPessoaJuridica.add(pessoaJuridica);
    }

    //MÉTODO ALTERAR
    public boolean Alterar(int id, PessoaJuridica novaPessoaJuridica) {
        for (int i = 0; i < listaPessoaJuridica.size(); i++) {
            PessoaJuridica pj = listaPessoaJuridica.get(i);
            if (pj.getID() == id) {
                listaPessoaJuridica.set(i, novaPessoaJuridica);
                return true;
            }
        }
        return false;
    }

    //MÉTODO EXCLUIR
    public boolean Excluir(int id) {
        Iterator<PessoaJuridica> iterator = listaPessoaJuridica.iterator();
        while (iterator.hasNext()) {
            PessoaJuridica pj = iterator.next();
            if (pj.getID() == id) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }

    //MÉTODO OBTER
    public PessoaJuridica Obter(int id) {
        for (PessoaJuridica pj : listaPessoaJuridica) {
            if (pj.getID() == id) {
                return pj;
            }
        }
        return null;
    }

    //MÉTODO OBTER TODOS
    public ArrayList<PessoaJuridica> ObterTodos() {
        return listaPessoaJuridica;
    }

    //MÉTODO PERSISTIR
    public void Persistir(String nomeArquivo) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nomeArquivo))) {
            out.writeObject(listaPessoaJuridica);
        }
    }

    //MÉTODO RECUPERAR
    public void Recuperar(String nomeArquivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(nomeArquivo))) {
            listaPessoaJuridica = (ArrayList<PessoaJuridica>) in.readObject();
        }
    }
}

