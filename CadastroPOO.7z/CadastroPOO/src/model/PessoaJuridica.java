/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.io.Serializable;
/**
 *
 * @author Mauricio
 */
public class PessoaJuridica extends Pessoa implements Serializable {
    private String cnpj;
    private static final long serialVersionUID = 3L;
    //MÉTODO CONSTRUTOR
    public PessoaJuridica(int id, String nome, String cnpj){
    super(id, nome);
    this.cnpj = cnpj;
    }
    //MÉTODOS SETTERS
    public void setCNPJ(String cnpj){
        this.cnpj = cnpj;
    }
    
    //MÉTODOS GETTERS
    public String getCNPJ(){
        return cnpj;
    }
    
    
    //MÉTODO EXIBIR
    @Override 
    public void Exibir(){
        super.Exibir();
        System.out.println("CNPJ: " + cnpj);
    }
    
}
