/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Mauricio
 */

//IMPORTANDO A INTERFACE
import java.io.Serializable;

public class Pessoa implements Serializable{
    private int id;
    private String nome;
    
     private static final long serialVersionUID = 1L;
     
    //CONSTRUTOR
    public Pessoa(int id, String nome){
        this.nome = nome;
        this.id = id;
    }
    
    //MÉTODOS SETTERS
    public void setID(int id){
        this.id = id;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    //MÉTODOS GETTERS
    public String getNome () {
         return nome;
    }
    public int getID () {
         return id;
    }
    
    //MÉTODO EXIBIR
    public void Exibir(){
        System.out.println("ID: " + id);
        System.out.println("Nome: "+ nome);
    }
}
