/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Mauricio
 */
import java.io.Serializable;

public class PessoaFisica extends Pessoa implements Serializable {
    private String cpf;
    private int idade;
     private static final long serialVersionUID = 2L;
    
//MÉTODO CONSTRUTOR
    public PessoaFisica(int id, String nome, String cpf, int idade){
    super(id, nome);
    this.cpf = cpf;
    this.idade = idade;
    }
    
    //MÉTODOS SETTERS
    public void setCPF(String cpf){
        this.cpf = cpf;
    }
    
    public void setIdade(int idade){
        this.idade = idade;
    }
    
    
    //MÉTODOS GETTERS
    public String getCPF(){
        return cpf;
    }
    
    public int getIdade(){
        return idade;
    }
    
    //MÉTODO EXIBIR
    @Override
    public void Exibir(){
        super.Exibir();
        System.out.println("CPF: " + cpf);
        System.out.println("Idade: " + idade);
    }
    
}
