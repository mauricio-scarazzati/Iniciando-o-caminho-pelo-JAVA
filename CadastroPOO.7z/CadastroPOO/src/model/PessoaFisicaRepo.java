/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

public class PessoaFisicaRepo {
    private ArrayList<PessoaFisica> listaPessoaFisica;

    // CONSTRUTOR
    public PessoaFisicaRepo() {
        listaPessoaFisica = new ArrayList<>();
    }
    //MÉTODO INSERIR
    public void Inserir(PessoaFisica pessoaFisica) {
        listaPessoaFisica.add(pessoaFisica);
    }

    //MÉTODO ALTERAR
    public boolean Alterar(int id,PessoaFisica novaPessoaFisica) {
        for (int i = 0; i < listaPessoaFisica.size(); i++) {
            PessoaFisica pf = listaPessoaFisica.get(i);
            if (pf.getID() == id) {
                listaPessoaFisica.set(i, novaPessoaFisica);
                return true;
            }
        }
        return false;
    }

    //MÉTODO EXCLUIR
    public boolean Excluir(int id) {
        Iterator<PessoaFisica> iterator = listaPessoaFisica.iterator();
        while (iterator.hasNext()) {
            PessoaFisica pf = iterator.next();
            if (pf.getID() == id) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }

    //MÉTODO OBTER
    public PessoaFisica Obter(int id) {
        for (PessoaFisica pf : listaPessoaFisica) {
            if (pf.getID() == id) {
                return pf;
            }
        }
        return null;
    }

    //MÉTODO OBTER TODOS
    public ArrayList<PessoaFisica> ObterTodos() {
        return listaPessoaFisica;
    }

    //MÉTODO PUBLICO PERSISTIR
    public void Persistir(String nomeArquivo) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(nomeArquivo))) {
            out.writeObject(listaPessoaFisica);
        }
    }

    //MÉTODO RECUPERAR
    public void Recuperar(String nomeArquivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(nomeArquivo))) {
            listaPessoaFisica = (ArrayList<PessoaFisica>) in.readObject();
        }
    }
}

