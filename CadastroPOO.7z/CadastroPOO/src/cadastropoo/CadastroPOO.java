
package cadastropoo;
import java.io.IOException;
import model.PessoaFisica;
import model.PessoaFisicaRepo;
import model.PessoaJuridica;
import model.PessoaJuridicaRepo;

public class CadastroPOO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
           
            PessoaFisicaRepo repo1 = new PessoaFisicaRepo();

            
            PessoaFisica pf1 = new PessoaFisica(1, "Ana", "11111111111",25);
            PessoaFisica pf2 = new PessoaFisica(2, "Carlos", "22222222222", 52);
            repo1.Inserir(pf1);
            repo1.Inserir(pf2);

            
            repo1.Persistir("pessoas_fisicas.ser");
            System.out.println("Dados de Pessoa Fisica Armazenados");
            
            PessoaFisicaRepo repo2 = new PessoaFisicaRepo();
            repo2.Recuperar("pessoas_fisicas.ser");

          
            System.out.println("Dados de Pessoa Fisica Recuperadas:");
            for (PessoaFisica pf : repo2.ObterTodos()) {
                pf.Exibir();
                System.out.println();
            }

           
            PessoaJuridicaRepo repo3 = new PessoaJuridicaRepo();

            
            PessoaJuridica pj1 = new PessoaJuridica(3, "XPTO Sales", "333333333333333");
            PessoaJuridica pj2 = new PessoaJuridica(4, "XPTO Solutions", "44444444444444");
            repo3.Inserir(pj1);
            repo3.Inserir(pj2);

            
            repo3.Persistir("pessoas_juridicas.ser");
            System.out.println("Dados de Pessoa Juridica Armazenados");

            
            PessoaJuridicaRepo repo4 = new PessoaJuridicaRepo();
            repo4.Recuperar("pessoas_juridicas.ser");

            
            System.out.println("Dados de Pessoa Juridica Recuperados:");
            for (PessoaJuridica pj : repo4.ObterTodos()) {
                pj.Exibir();
                System.out.println();
            }

        } catch (IOException e) {
            System.err.println("Erro ao acessar o arquivo: " + e.getMessage());
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.err.println("Erro ao desserializar o objeto: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
}
